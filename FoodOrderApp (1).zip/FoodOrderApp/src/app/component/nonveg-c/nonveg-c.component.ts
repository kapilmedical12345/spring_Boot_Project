import { Component } from '@angular/core';

@Component({
  selector: 'app-nonveg-c',
  templateUrl: './nonveg-c.component.html',
  styleUrls: ['./nonveg-c.component.css']
})
export class NonvegCComponent {

}
