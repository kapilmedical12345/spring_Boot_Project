import { Component } from '@angular/core';

@Component({
  selector: 'app-veg-c',
  templateUrl: './veg-c.component.html',
  styleUrls: ['./veg-c.component.css']
})
export class VegCComponent {

}
