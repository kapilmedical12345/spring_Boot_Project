import { Component } from '@angular/core';

@Component({
  selector: 'app-paydone',
  templateUrl: './paydone.component.html',
  styleUrls: ['./paydone.component.css']
})
export class PaydoneComponent {

}
