export class cust
   {
             constructor(
             public customerfname:string,
             public customerlname:string,
             public customermobile:number,
             public customeremailid:string,
             public customerpassword:String ){}
    }